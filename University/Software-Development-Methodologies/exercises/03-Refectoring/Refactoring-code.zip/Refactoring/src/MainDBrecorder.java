
public class MainDBrecorder {

	public static void main(String[] args) {
		DBrecorder.fromSourceToDB("prova.txt", "file");
		//DBrecorder.fromSourceToDB("localhost:2017", "net");
		//DBrecorder.fromSourceToDB("mars.ing.unimo.it:2017", "net");
	}

}
