
public class MainDBrecorder {

	public static void main(String[] args) {
		DBrecorderHints.fromSourceToDB("prova.txt", "file");
		//DBrecorderHints.fromSourceToDB("localhost:2017", "net");
		//DBrecorderHints.fromSourceToDB("mars.ing.unimo.it:2017", "net");
	}

}
